# sandwichr 1.0.3
Fixed confidence interval. Update vignettes.

# sandwichr 1.0.2
Used stratified k-fold validation for model evaluation. Update vignettes.

# sandwichr 1.0.1
Used S3 Methods for plotting and summarizing model outputs. Fixed a few bugs.

# sandwichr 1.0.0
First release.

* Added a `NEWS.md` file to track changes to the package.
